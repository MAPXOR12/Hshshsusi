const {EmbedBuilder,Discord }= require ("discord.js")
const {  ApplicationCommandOptionType } = require("discord.js")
module.exports = {
  name: "volume",
description: "Adjusts the Volume of the Music",
options:[

  {
  
				name: "number",
				description: "What should be the Volume? It must be between 0 & 150",
  type:ApplicationCommandOptionType.Number,
				required: true
    
  }
],
  category: ["music"],
  enabled: true,
  memberPermissions: ["SendMessages"],
  botPermissions: ["SendMessages", "EmbedLinks"],
  ownerOnly: true,
  cooldown: 6000,
  prime:true,
  run: async (interaction, bot) => {
    try {
			//things u can directly access in an interaction!
			const {
				member,
				channelId,
				guildId,
				applicationId,
				commandName,
				deferred,
				replied,
				ephemeral,
				options,
				id,
				createdTimestamp
			} = interaction;
			const {
				guild
			} = member;
			const {
				channel
			} = member.voice;
			if (!channel) return interaction.reply({
				embeds: [
					new EmbedBuilder().setColor(config.embed.Color).setTitle(`**Please join ${guild.members.me.voice.channel ? "__my__" : "a"} VoiceChannel First!**`)
				],
				ephemeral: true
			})
			if (channel.guild.members.me.voice.channel && channel.guild.members.me.voice.channel.id != channel.id) {
				return interaction.reply({
					embeds: [new EmbedBuilder()
						.setColor(config.embed.Color)
						
						.setTitle(` Join __my__ Voice Channel!`)
						.setDescription(`<#${guild.members.me.voice.channel.id}>`)
					],
					ephemeral: true
				});
			}
			try {
				let newQueue = distube.getQueue(guildId);
				if (!newQueue || !newQueue.songs || newQueue.songs.length == 0) return interaction.reply({
					embeds: [
						new EmbedBuilder().setColor(config.embed.Color).setTitle(` **I am nothing Playing right now!**`)
					],
					ephemeral: true
				})
				/*if (check_if_dj(client, member, newQueue.songs[0])) {
					return interaction.reply({
						embeds: [new MessageEmbed()
							.setColor(ee.wrongcolor)
							.setFooter(ee.footertext, ee.footericon)
							.setTitle(`${client.allEmojis.x} **You are not a DJ and not the Song Requester!**`)
							.setDescription(`**DJ-ROLES:**\n> ${check_if_dj(client, member, newQueue.songs[0])}`)
						],
						ephemeral: true
					});
				}*/
				let volume = options.getInteger("volume")
				if (volume > 150 || volume < 0) return interaction.reply({
					embeds: [
						new EmbedBuilder().setColor(config.embed.Color).setTitle(`**The Volume must be between \`0\` and \`150\`!**`)
					],
					ephemeral: true
				})
				await newQueue.setVolume(volume);
				interaction.reply({
					embeds: [new EmbedBuilder()
					  .setColor(config.embed.Color)
					  .setTimestamp()
					  .setTitle(`🔊 **Changed the Volume to \`${volume}\`!**`)
					]
				})
			} catch (e) {
				console.log(e.stack ? e.stack : e)
				interaction.editReply({
					content: `Error: `,
					embeds: [
						new EmbedBuilder().setColor(config.embed.Color)
						.setDescription(`\`\`\`${e}\`\`\``)
					],
					ephemeral: true
				})
			}
		} catch (e) {
			console.log(e.message)
		}
	}
}