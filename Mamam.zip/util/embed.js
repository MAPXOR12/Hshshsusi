const mainembed = {
	color:"BLACK",
	title: 'hama',
	url: '',
	author: {
		name: 'BoBo',
		icon_url: ``,
	
	},
	description: '',
	thumbnail: {
		url: '',
	},
	fields: [
		{
			name: '',
			value: '',
		},
		{
			name: '\u200b',
			value: '\u200b',
			inline: false,
		},
	
	],
	image: {
		url: '',
	},
	timestamp: new Date(),
	footer: {
		text: '',
		icon_url: '',
	},
};
const newsEmbed = {
  color: config.embed.Color,
  title:"",
  author:{
    name: '',
    icon_url:'',
  },
  description:'',
  image:{ 
    url:'',
  },
}
module.exports = [newsEmbed, mainembed]